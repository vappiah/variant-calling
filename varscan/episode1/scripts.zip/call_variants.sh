#!/bin/bash


for sample in normal tumor
bcftools mpileup -O b -o ${sample}.bcf --threads 8 -f $ref -q 20 -Q 30 output.sorted.bam

