#!/bin/bash

conda config --add channels bioconda
conda config --add channels conda-forge
conda env create -f environment.yaml




./download_data.sh

fastqc data/fastq/raw_reads/*.fastq.gz
multiqc data/fastq/raw_reads/*_fastqc.zip

trim_reads.sh


fastqc data/fastq/trimmed_reads/*.fastq.gz
multiqc data/fastq/trimmed_reads/*_fastqc.zip



#map reads to the reference genome
./map_reads.sh

./process_bams.sh

mkdir variants
ls BAMS/*.final.bam >bamlist.txt
samtools mpileup -Q 28 -q 1 -f data/ref/hg19.chr5.fa -b bamlist.txt -o variants/normal-tumor.mpileup

#lets generate a pileup file


#this takes about 5 mininutes for each sample
#this is needed if using an old samtools version
#samtools mpileup -6 -Q 28 -q 1 -f data/ref/hg19.chr5.fa BAMS/normal.final.bam -o variants/normal.pileup  
#samtools mpileup -6 -Q 28 -q 1 -f data/ref/hg19.chr5.fa BAMS/tumor.final.bam -o variants/tumor.pileup
#Q minimum base quality
#q minimum mapping quality
#varscan somatic variants/normal.pileup variants/tumor.pileup --tumor-purity 0.5 --normal-purity 1 --output-vcf variants/variants.vcf --min-avg-qual 28	
#varscan somatic variants/normal.pileup variants/tumor.pileup --normal-purity 1 --tumor-purity 0.5 --output-vcf variants/variants.vcf
#varscan somatic BAMS/normal.final.bam BAMS/tumor.final.bam --normal-purity 1 --tumor-purity 0.5 --output-vcf variants/variants.vcf



#call variants
varscan somatic variants/normal-tumor.mpileup variants/variants.vcf --mpileup 1 --normal-purity 1 --tumor-purity 0.5 --output-vcf 1 


#--tumor-purity estimated “Estimated purity (tumor content) of normal sample”
#--normal-purity  “Estimated purity (non-tumor content) of normal sample”


bgzip variants/variants.vcf.snp 
bgzip variants/variants.vcf.indel

bcftools index variants/variants.vcf.snp.gz
bcftools index variants/variants.vcf.indel.gz

bcftools merge variants/variants.vcf.indel.gz variants/variants.vcf.indel.gz -o variants.all.vcf -O vcf








Here is another tutorial for those interested in Bioinformatics

https://youtu.be/3swFCSt2_x4

