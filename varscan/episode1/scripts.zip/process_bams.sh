#!/bin/bash


#left align reads
samtools faidx data/ref/hg19.chr5_12_17.fa

cat BAMS/normal.dedup.bam | bamleftalign -f data/ref/hg19.chr5_12_17.fa  > BAMS/normal.leftalign.bam
cat BAMS/tumor.dedup.bam | bamleftalign -f data/ref/hg19.chr5_12_17.fa  > BAMS/tumor.leftalign.bam


#Recalibrate read mapping qualities
samtools calmd -@ 8 -bAr BAMS/normal.leftalign.bam data/ref/hg19.chr5_12_17.fa > BAMS/normal.calmd.bam
samtools calmd -@ 8 -bAr BAMS/tumor.leftalign.bam data/ref/hg19.chr5_12_17.fa > BAMS/tumor.calmd.bam

#this message is a bug
#EOF marker is absent. The input is probably truncated


#final filtering
bamtools filter -in BAMS/normal.calmd.bam -mapQuality "<=254" >BAMS/normal.final.bam
bamtools filter -in BAMS/tumor.calmd.bam -mapQuality "<=254" >BAMS/tumor.final.bam


